# Arquitectura del Proyecto — Taller Mecánico

## Stack

| Capa | Tecnología | Versión |
|------|-----------|---------|
| Framework | Next.js | 15 (App Router) |
| Lenguaje | TypeScript | 5.x |
| Estilos | Tailwind CSS | 3.x |
| Componentes | shadcn/ui | latest |
| Base de datos | Supabase | latest |
| Estado | Zustand | 4.x |
| Formularios | React Hook Form + Zod | latest |
| Notificaciones | Sonner | latest |
| Deploy | Vercel | - |

---

## Estructura de carpetas

```
taller-system/
├── src/
│   ├── app/                          # Next.js App Router
│   │   ├── (auth)/                   # Grupo: rutas de autenticación
│   │   │   ├── login/
│   │   │   │   └── page.tsx
│   │   │   └── layout.tsx
│   │   ├── (dashboard)/              # Grupo: rutas protegidas
│   │   │   ├── layout.tsx            # Layout con sidebar + auth check
│   │   │   ├── page.tsx              # Dashboard principal (owner)
│   │   │   ├── orders/
│   │   │   │   ├── page.tsx          # Lista de órdenes (kanban + lista)
│   │   │   │   ├── new/
│   │   │   │   │   └── page.tsx      # Crear nueva orden
│   │   │   │   └── [id]/
│   │   │   │       └── page.tsx      # Detalle y edición de orden
│   │   │   ├── vehicles/
│   │   │   │   ├── page.tsx          # Lista de vehículos/clientes
│   │   │   │   └── [id]/
│   │   │   │       └── page.tsx      # Historial del vehículo
│   │   │   ├── commissions/
│   │   │   │   └── page.tsx          # Control de comisiones (solo owner)
│   │   │   ├── mechanics/
│   │   │   │   └── page.tsx          # Gestión de mecánicos (solo owner)
│   │   │   └── reports/
│   │   │       └── page.tsx          # Reportes exportables (solo owner)
│   │   ├── api/
│   │   │   └── orders/
│   │   │       └── route.ts          # API routes si se necesitan
│   │   ├── layout.tsx                # Root layout
│   │   └── globals.css
│   │
│   ├── components/
│   │   ├── ui/                       # shadcn/ui (auto-generados, no editar)
│   │   ├── layout/
│   │   │   ├── Sidebar.tsx           # Sidebar de navegación por rol
│   │   │   ├── Header.tsx            # Header con usuario activo
│   │   │   └── MobileNav.tsx         # Navegación móvil (bottom tabs)
│   │   ├── orders/
│   │   │   ├── OrderCard.tsx         # Tarjeta de orden en kanban
│   │   │   ├── OrderKanban.tsx       # Vista kanban de estados
│   │   │   ├── OrderList.tsx         # Vista lista de órdenes
│   │   │   ├── OrderForm.tsx         # Formulario crear/editar orden
│   │   │   ├── OrderStatusBadge.tsx  # Badge de estado con color
│   │   │   ├── StatusChangeModal.tsx # Modal para cambiar estado
│   │   │   └── MechanicAssigner.tsx  # Selector de mecánicos para orden
│   │   ├── vehicles/
│   │   │   ├── VehicleForm.tsx       # Formulario de vehículo/propietario
│   │   │   ├── VehicleHistory.tsx    # Historial de servicios del vehículo
│   │   │   └── PlateSearch.tsx       # Búsqueda por placa (autocomplete)
│   │   ├── dashboard/
│   │   │   ├── StatsCards.tsx        # Tarjetas de métricas del día
│   │   │   ├── ActiveOrders.tsx      # Lista de órdenes activas
│   │   │   └── PendingCommissions.tsx # Resumen de comisiones pendientes
│   │   └── commissions/
│   │       ├── CommissionTable.tsx   # Tabla de comisiones por mecánico
│   │       └── PaymentModal.tsx      # Modal para marcar pago de comisiones
│   │
│   ├── lib/
│   │   ├── supabase/
│   │   │   ├── client.ts             # Cliente Supabase para el browser
│   │   │   ├── server.ts             # Cliente Supabase para Server Components
│   │   │   └── middleware.ts         # Cliente para middleware
│   │   ├── validations/
│   │   │   ├── order.schema.ts       # Zod schemas para órdenes
│   │   │   ├── vehicle.schema.ts     # Zod schemas para vehículos
│   │   │   └── profile.schema.ts     # Zod schemas para perfiles
│   │   └── utils.ts                  # Helpers generales
│   │
│   ├── hooks/
│   │   ├── useOrders.ts              # Hook para órdenes con realtime
│   │   ├── useVehicles.ts            # Hook para vehículos
│   │   ├── useCommissions.ts         # Hook para comisiones
│   │   ├── useProfile.ts             # Hook para perfil del usuario
│   │   └── useDashboard.ts           # Hook para stats del dashboard
│   │
│   ├── stores/
│   │   ├── authStore.ts              # Estado de autenticación (Zustand)
│   │   └── ordersStore.ts            # Caché local de órdenes (Zustand)
│   │
│   └── types/
│       ├── database.types.ts         # Tipos generados por Supabase CLI
│       └── app.types.ts              # Tipos adicionales de la aplicación
│
├── public/
├── supabase/
│   └── migrations/                   # Migraciones SQL en orden numérico
├── .env.local                        # Variables de entorno (no commitear)
├── .env.example                      # Plantilla de variables
├── middleware.ts                     # Middleware de Next.js para auth
├── next.config.ts
├── tailwind.config.ts
└── tsconfig.json
```

---

## Variables de entorno

Crear `.env.local` con:

```env
NEXT_PUBLIC_SUPABASE_URL=tu_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=tu_service_role_key
```

---

## Flujo de autenticación

```
Usuario accede a cualquier ruta
        ↓
middleware.ts verifica sesión Supabase
        ↓
¿Tiene sesión?
  NO → redirect a /login
  SÍ → verificar rol en profiles
        ↓
    owner      → acceso completo
    receptionist → sin /commissions ni /mechanics ni /reports
    mechanic   → solo /orders (sus asignadas)
```

---

## Convenciones de código

### Nombrado
- Componentes: `PascalCase`
- Hooks: `camelCase` con prefijo `use`
- Archivos de componentes: `PascalCase.tsx`
- Archivos de utilidades: `camelCase.ts`
- Tipos/interfaces: `PascalCase` con prefijo `T` para tipos, `I` omitido

### Patrones
- **Server Components por defecto**. Solo usar `"use client"` cuando se necesita interactividad
- **Formularios siempre con React Hook Form + Zod**. Sin formularios manuales con `useState`
- **Data fetching en Server Components** cuando sea posible. Hooks de cliente para realtime
- **Error handling**: siempre con `try/catch` y toast de error visible al usuario
- **Loading states**: siempre con skeleton, nunca pantalla en blanco

### Colores de estado de orden (Tailwind)

```typescript
export const ORDER_STATUS_CONFIG = {
  received:       { label: 'Recibido',        color: 'bg-slate-100 text-slate-700' },
  diagnosing:     { label: 'Diagnóstico',     color: 'bg-blue-100 text-blue-700' },
  waiting_parts:  { label: 'Esperando piezas',color: 'bg-yellow-100 text-yellow-700' },
  in_progress:    { label: 'En proceso',      color: 'bg-orange-100 text-orange-700' },
  quality_check:  { label: 'Control calidad', color: 'bg-purple-100 text-purple-700' },
  ready:          { label: 'Listo',           color: 'bg-green-100 text-green-700' },
  delivered:      { label: 'Entregado',       color: 'bg-gray-100 text-gray-500' },
}
```

---

## Comandos de instalación

```bash
# 1. Crear proyecto
npx create-next-app@latest taller-system --typescript --tailwind --app --src-dir

# 2. Instalar dependencias
cd taller-system
npm install @supabase/supabase-js @supabase/ssr
npm install zustand react-hook-form @hookform/resolvers zod
npm install sonner
npm install date-fns

# 3. Instalar shadcn/ui
npx shadcn@latest init
npx shadcn@latest add button card input label select badge dialog sheet table tabs skeleton form toast

# 4. Instalar Supabase CLI (para generar tipos)
npm install -D supabase

# 5. Generar tipos de la base de datos
npx supabase gen types typescript --project-id TU_PROJECT_ID > src/types/database.types.ts
```
