# PRD — Sistema de Gestión para Talleres Mecánicos

## Visión del producto

Sistema web de gestión operativa para talleres mecánicos en Colombia. Resuelve el problema central que Tuulapp no resuelve: **control interno del negocio**. El dueño sabe en tiempo real qué vehículos están en taller, quién hizo qué trabajo, y cuánto le debe a cada mecánico. Los empleados registran órdenes en 3 toques desde cualquier dispositivo con navegador.

## Problema real que resuelve

Los talleres mecánicos en ciudades intermedias de Colombia operan por WhatsApp y papel. El dueño no sabe:
- Cuántos vehículos entraron hoy ni cuál es su estado
- Quién recibió a qué cliente
- Qué mecánico ejecutó qué trabajo
- Cuánto debe pagarle a cada mecánico al cierre de semana

## Usuarios

| Rol | Descripción | Acceso |
|-----|-------------|--------|
| `owner` | Dueño del taller | Dashboard completo + reportes + configuración |
| `receptionist` | Asesor de servicio | Crear/editar órdenes + ver estado |
| `mechanic` | Mecánico | Ver sus órdenes asignadas + marcar avance |

## Stack técnico

- **Frontend:** Next.js 15 (App Router) + TypeScript + Tailwind CSS
- **Backend:** Supabase (PostgreSQL + Auth + Realtime + Storage)
- **UI Components:** shadcn/ui
- **Estado global:** Zustand
- **Formularios:** React Hook Form + Zod
- **Notificaciones:** Sonner (toasts)
- **Deploy:** Vercel

## Módulos — Fase 1 (entregar primero)

### M1 — Autenticación y roles
- Login con email/password vía Supabase Auth
- Roles: `owner`, `receptionist`, `mechanic`
- Row Level Security (RLS) en todas las tablas
- Redirección automática por rol al login

### M2 — Gestión de órdenes de servicio
- Crear orden: placa, propietario, teléfono, vehículo (marca/modelo/año), kilometraje, descripción del problema
- Asignar recepcionista (quien recibe) y mecánico(s) (quien ejecuta)
- Estados de orden: `received` → `diagnosing` → `waiting_parts` → `in_progress` → `quality_check` → `ready` → `delivered`
- Cambio de estado con un toque + nota opcional
- Búsqueda por placa o nombre de propietario
- Vista kanban por estado (columnas) y vista lista

### M3 — Control de comisiones
- Cada orden tiene un valor de mano de obra
- Cada mecánico asignado tiene un porcentaje de comisión configurable
- Acumulado de comisiones por mecánico en tiempo real
- Corte semanal: el dueño marca el pago y el contador resetea
- Historial de cortes anteriores

### M4 — Dashboard del dueño
- Órdenes del día: recibidas, en proceso, listas para entrega
- Ingresos del día (mano de obra total)
- Comisiones pendientes por mecánico (cuánto debo pagarle a cada uno)
- Órdenes atrasadas (más de X días sin avance)
- Últimos vehículos atendidos

### M5 — Historial de vehículos y clientes
- Búsqueda por placa → ver todos los servicios anteriores
- Búsqueda por propietario → ver todos sus vehículos
- Ficha del vehículo: marca, modelo, año, historial completo de servicios

## Módulos — Fase 2

### M6 — Reportes exportables
- Reporte semanal/mensual de ingresos
- Reporte de comisiones por mecánico por período
- Exportar a PDF
- Filtros por rango de fechas y por mecánico

### M7 — Notificaciones WhatsApp (integración futura)
- Al cambiar estado de orden → notificación automática al cliente
- Plantillas configurables por el dueño
- Integración vía WhatsApp Business API (Cloud API de Meta)

## Reglas de negocio críticas

1. Una orden SIEMPRE tiene un recepcionista asignado
2. Una orden puede tener uno o más mecánicos asignados
3. Solo el `owner` puede ver y gestionar comisiones
4. Solo el `owner` puede configurar porcentajes de comisión
5. Los mecánicos solo ven las órdenes que tienen asignadas
6. El recepcionista ve todas las órdenes
7. Al marcar una orden como `delivered`, se calcula y registra la comisión final
8. Los cortes de comisión no eliminan el historial, lo archivan

## Criterios de aceptación globales

- Crear una orden completa en menos de 60 segundos
- La app funciona correctamente en móvil (mecánicos usan el celular)
- Actualizaciones de estado visibles en tiempo real sin recargar página
- Sin pérdida de datos: todas las acciones son auditables
- Tiempo de carga inicial menor a 2 segundos
