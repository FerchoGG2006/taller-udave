# Database Schema — Taller Mecánico

## Instrucciones para el IDE

Ejecutar en Supabase SQL Editor en este orden exacto. Cada bloque es independiente pero deben ejecutarse en secuencia.

---

## 001 — Extensiones y tipos

```sql
-- Habilitar extensiones necesarias
create extension if not exists "uuid-ossp";

-- Tipos enumerados
create type user_role as enum ('owner', 'receptionist', 'mechanic');

create type order_status as enum (
  'received',
  'diagnosing', 
  'waiting_parts',
  'in_progress',
  'quality_check',
  'ready',
  'delivered'
);
```

---

## 002 — Tabla: profiles

Extiende `auth.users` de Supabase con datos del negocio.

```sql
create table profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  full_name text not null,
  phone text,
  role user_role not null default 'mechanic',
  commission_percentage numeric(5,2) default 0.00, -- solo aplica para mecánicos
  is_active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- RLS
alter table profiles enable row level security;

-- El owner ve todos los perfiles
create policy "owner_see_all_profiles"
  on profiles for select
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid() and p.role = 'owner'
    )
  );

-- Cada usuario ve su propio perfil
create policy "user_see_own_profile"
  on profiles for select
  using (id = auth.uid());

-- Solo owner puede crear/editar perfiles
create policy "owner_manage_profiles"
  on profiles for all
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid() and p.role = 'owner'
    )
  );

-- Trigger para updated_at
create or replace function handle_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger profiles_updated_at
  before update on profiles
  for each row execute function handle_updated_at();

-- Trigger: crear perfil automáticamente al registrar usuario en auth
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', 'Sin nombre'),
    coalesce((new.raw_user_meta_data->>'role')::user_role, 'mechanic')
  );
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();
```

---

## 003 — Tabla: vehicles

```sql
create table vehicles (
  id uuid default uuid_generate_v4() primary key,
  plate text not null unique, -- placa del vehículo, ej: "ABC123"
  brand text not null,
  model text not null,
  year integer,
  color text,
  owner_name text not null,
  owner_phone text not null,
  owner_email text,
  notes text, -- notas permanentes del vehículo
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index vehicles_plate_idx on vehicles (lower(plate));
create index vehicles_owner_name_idx on vehicles (lower(owner_name));

alter table vehicles enable row level security;

create trigger vehicles_updated_at
  before update on vehicles
  for each row execute function handle_updated_at();

-- Recepcionistas y owner pueden ver y crear vehículos
create policy "staff_manage_vehicles"
  on vehicles for all
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid()
      and p.role in ('owner', 'receptionist')
    )
  );

-- Mecánicos solo ven vehículos de órdenes asignadas a ellos
create policy "mechanic_see_assigned_vehicles"
  on vehicles for select
  using (
    exists (
      select 1 from service_orders so
      join order_mechanics om on om.order_id = so.id
      where so.vehicle_id = vehicles.id
      and om.mechanic_id = auth.uid()
    )
  );
```

---

## 004 — Tabla: service_orders

```sql
create table service_orders (
  id uuid default uuid_generate_v4() primary key,
  order_number serial, -- número legible para mostrar al cliente
  vehicle_id uuid references vehicles(id) not null,
  receptionist_id uuid references profiles(id) not null,
  status order_status default 'received',
  mileage integer, -- kilometraje al ingreso
  problem_description text not null,
  diagnosis text, -- diagnóstico del mecánico
  labor_cost numeric(12,2) default 0.00, -- costo de mano de obra
  parts_cost numeric(12,2) default 0.00, -- costo de repuestos (referencial)
  total_cost numeric(12,2) generated always as (labor_cost + parts_cost) stored,
  estimated_delivery timestamptz,
  actual_delivery timestamptz,
  is_paid boolean default false,
  internal_notes text, -- notas internas, no visibles al cliente
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index service_orders_vehicle_idx on service_orders (vehicle_id);
create index service_orders_status_idx on service_orders (status);
create index service_orders_receptionist_idx on service_orders (receptionist_id);
create index service_orders_created_at_idx on service_orders (created_at desc);

alter table service_orders enable row level security;

create trigger service_orders_updated_at
  before update on service_orders
  for each row execute function handle_updated_at();

-- Owner y recepcionistas ven todas las órdenes
create policy "staff_see_all_orders"
  on service_orders for all
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid()
      and p.role in ('owner', 'receptionist')
    )
  );

-- Mecánicos solo ven sus órdenes asignadas
create policy "mechanic_see_assigned_orders"
  on service_orders for select
  using (
    exists (
      select 1 from order_mechanics om
      where om.order_id = service_orders.id
      and om.mechanic_id = auth.uid()
    )
  );
```

---

## 005 — Tabla: order_mechanics

Relación muchos-a-muchos entre órdenes y mecánicos.

```sql
create table order_mechanics (
  id uuid default uuid_generate_v4() primary key,
  order_id uuid references service_orders(id) on delete cascade not null,
  mechanic_id uuid references profiles(id) not null,
  commission_percentage numeric(5,2) not null, -- snapshot del % en el momento de asignación
  commission_amount numeric(12,2) default 0.00, -- calculado al entregar
  is_commission_paid boolean default false,
  assigned_at timestamptz default now(),
  unique(order_id, mechanic_id)
);

create index order_mechanics_order_idx on order_mechanics (order_id);
create index order_mechanics_mechanic_idx on order_mechanics (mechanic_id);

alter table order_mechanics enable row level security;

-- Owner gestiona todo
create policy "owner_manage_order_mechanics"
  on order_mechanics for all
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid() and p.role = 'owner'
    )
  );

-- Recepcionistas asignan mecánicos
create policy "receptionist_assign_mechanics"
  on order_mechanics for insert
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid() and p.role = 'receptionist'
    )
  );

-- Mecánicos ven sus propias asignaciones
create policy "mechanic_see_own_assignments"
  on order_mechanics for select
  using (mechanic_id = auth.uid());
```

---

## 006 — Tabla: order_status_history

Auditoría completa de cambios de estado.

```sql
create table order_status_history (
  id uuid default uuid_generate_v4() primary key,
  order_id uuid references service_orders(id) on delete cascade not null,
  changed_by uuid references profiles(id) not null,
  previous_status order_status,
  new_status order_status not null,
  note text,
  created_at timestamptz default now()
);

create index order_status_history_order_idx on order_status_history (order_id);

alter table order_status_history enable row level security;

-- Owner y recepcionistas ven el historial completo
create policy "staff_see_history"
  on order_status_history for select
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid()
      and p.role in ('owner', 'receptionist')
    )
  );

-- Cualquier usuario autenticado puede insertar (se valida en la lógica de app)
create policy "authenticated_insert_history"
  on order_status_history for insert
  with check (auth.uid() is not null);

-- Trigger: registrar automáticamente cada cambio de estado en service_orders
create or replace function log_order_status_change()
returns trigger as $$
begin
  if old.status is distinct from new.status then
    insert into order_status_history (order_id, changed_by, previous_status, new_status)
    values (new.id, auth.uid(), old.status, new.status);
  end if;
  return new;
end;
$$ language plpgsql security definer;

create trigger order_status_change_log
  after update on service_orders
  for each row execute function log_order_status_change();
```

---

## 007 — Tabla: commission_periods

Períodos de corte de comisiones (semanal o a demanda).

```sql
create table commission_periods (
  id uuid default uuid_generate_v4() primary key,
  mechanic_id uuid references profiles(id) not null,
  period_start timestamptz not null,
  period_end timestamptz not null,
  total_labor_value numeric(12,2) not null default 0.00,
  total_commission numeric(12,2) not null default 0.00,
  is_paid boolean default false,
  paid_at timestamptz,
  paid_by uuid references profiles(id),
  notes text,
  created_at timestamptz default now()
);

create index commission_periods_mechanic_idx on commission_periods (mechanic_id);
create index commission_periods_paid_idx on commission_periods (is_paid);

alter table commission_periods enable row level security;

-- Solo owner gestiona períodos de comisión
create policy "owner_manage_commission_periods"
  on commission_periods for all
  using (
    exists (
      select 1 from profiles p
      where p.id = auth.uid() and p.role = 'owner'
    )
  );
```

---

## 008 — Vistas útiles

```sql
-- Vista: órdenes con info completa (para listados)
create or replace view orders_full_view as
select
  so.id,
  so.order_number,
  so.status,
  so.labor_cost,
  so.parts_cost,
  so.total_cost,
  so.problem_description,
  so.mileage,
  so.estimated_delivery,
  so.is_paid,
  so.created_at,
  so.updated_at,
  v.plate,
  v.brand,
  v.model,
  v.year,
  v.color,
  v.owner_name,
  v.owner_phone,
  p.full_name as receptionist_name,
  -- Array de mecánicos asignados
  coalesce(
    json_agg(
      json_build_object(
        'id', pr.id,
        'name', pr.full_name,
        'commission_percentage', om.commission_percentage,
        'commission_amount', om.commission_amount,
        'is_commission_paid', om.is_commission_paid
      )
    ) filter (where pr.id is not null),
    '[]'
  ) as mechanics
from service_orders so
join vehicles v on v.id = so.vehicle_id
join profiles p on p.id = so.receptionist_id
left join order_mechanics om on om.order_id = so.id
left join profiles pr on pr.id = om.mechanic_id
group by so.id, v.id, p.id;

-- Vista: dashboard del dueño (estadísticas del día)
create or replace view dashboard_today as
select
  count(*) filter (where status != 'delivered') as active_orders,
  count(*) filter (where status = 'received' and created_at::date = current_date) as received_today,
  count(*) filter (where status = 'ready') as ready_for_delivery,
  count(*) filter (where status = 'delivered' and actual_delivery::date = current_date) as delivered_today,
  coalesce(sum(labor_cost) filter (where status = 'delivered' and actual_delivery::date = current_date), 0) as revenue_today,
  coalesce(sum(labor_cost) filter (where status != 'delivered'), 0) as pending_revenue
from service_orders;

-- Vista: comisiones pendientes por mecánico
create or replace view pending_commissions as
select
  p.id as mechanic_id,
  p.full_name as mechanic_name,
  count(om.id) as pending_orders,
  coalesce(sum(om.commission_amount), 0) as total_pending,
  min(so.created_at) as oldest_order_date
from profiles p
join order_mechanics om on om.mechanic_id = p.id
join service_orders so on so.id = om.order_id
where om.is_commission_paid = false
and so.status = 'delivered'
group by p.id, p.full_name;
```

---

## 009 — Función: calcular y registrar comisiones al entregar

```sql
create or replace function calculate_commissions_on_delivery()
returns trigger as $$
begin
  -- Solo ejecutar cuando el status cambia a 'delivered'
  if new.status = 'delivered' and old.status != 'delivered' then
    -- Registrar la fecha real de entrega
    new.actual_delivery = now();
    
    -- Calcular comisión para cada mecánico asignado
    update order_mechanics
    set commission_amount = (new.labor_cost * commission_percentage / 100)
    where order_id = new.id;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger calculate_commissions
  before update on service_orders
  for each row execute function calculate_commissions_on_delivery();
```

---

## 010 — Habilitar Realtime

```sql
-- Habilitar realtime para actualizaciones en vivo en el dashboard
alter publication supabase_realtime add table service_orders;
alter publication supabase_realtime add table order_status_history;
alter publication supabase_realtime add table order_mechanics;
```

---

## Datos de prueba (solo desarrollo)

```sql
-- EJECUTAR SOLO EN ENTORNO DE DESARROLLO
-- Crear usuario owner directamente (normalmente se hace desde la UI de Supabase Auth)

-- Insertar vehículo de prueba
insert into vehicles (plate, brand, model, year, color, owner_name, owner_phone)
values ('ABC123', 'Chevrolet', 'Spark', 2019, 'Rojo', 'Juan Pérez', '3001234567');

-- Verificar vistas
select * from dashboard_today;
select * from pending_commissions;
```
