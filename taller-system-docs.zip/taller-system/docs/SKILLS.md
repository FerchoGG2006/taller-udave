# SKILLS — Instrucciones de desarrollo por módulo

> Este archivo es la guía de implementación para el IDE. Cada skill describe exactamente qué construir, cómo construirlo y qué errores evitar. Seguir en orden estricto.

---

## SKILL 01 — Setup inicial del proyecto

### Objetivo
Tener el proyecto corriendo localmente con Supabase conectado y autenticación funcionando.

### Pasos en orden

1. Ejecutar comandos de instalación del archivo `ARCHITECTURE.md`
2. Crear `.env.local` con las variables de Supabase
3. Crear `src/lib/supabase/client.ts`:

```typescript
import { createBrowserClient } from '@supabase/ssr'
import type { Database } from '@/types/database.types'

export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
```

4. Crear `src/lib/supabase/server.ts`:

```typescript
import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'
import type { Database } from '@/types/database.types'

export async function createClient() {
  const cookieStore = await cookies()
  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() { return cookieStore.getAll() },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            )
          } catch {}
        },
      },
    }
  )
}
```

5. Crear `middleware.ts` en la raíz:

```typescript
import { createServerClient } from '@supabase/ssr'
import { NextResponse, type NextRequest } from 'next/server'

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() { return request.cookies.getAll() },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
          supabaseResponse = NextResponse.next({ request })
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          )
        },
      },
    }
  )

  const { data: { user } } = await supabase.auth.getUser()

  // Rutas públicas
  const publicRoutes = ['/login']
  const isPublicRoute = publicRoutes.some(route => request.nextUrl.pathname.startsWith(route))

  if (!user && !isPublicRoute) {
    const url = request.nextUrl.clone()
    url.pathname = '/login'
    return NextResponse.redirect(url)
  }

  if (user && request.nextUrl.pathname === '/login') {
    const url = request.nextUrl.clone()
    url.pathname = '/'
    return NextResponse.redirect(url)
  }

  return supabaseResponse
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)'],
}
```

6. Ejecutar migraciones SQL del archivo `DATABASE.md` en Supabase SQL Editor, en orden de 001 a 010.

### Verificación
- `npm run dev` sin errores
- Navegar a `/login` muestra la pantalla de login
- Navegar a `/` sin sesión redirige a `/login`

---

## SKILL 02 — Autenticación y perfil de usuario

### Objetivo
Login funcional que redirige según el rol del usuario.

### Archivos a crear

**`src/app/(auth)/login/page.tsx`** — Página de login:
- Formulario con email y password usando React Hook Form + Zod
- Schema de validación: email válido, password mínimo 6 caracteres
- Al hacer submit: `supabase.auth.signInWithPassword()`
- Si error: mostrar toast de error con Sonner
- Si éxito: `router.push('/')` — el middleware y el layout se encargan del resto
- UI: centrada, logo del taller o nombre, sin distracciones

**`src/hooks/useProfile.ts`** — Hook de perfil:

```typescript
// Obtener el perfil del usuario autenticado incluyendo su rol
// Usar con: const { profile, loading } = useProfile()
// Guardar en authStore de Zustand para acceso global
```

**`src/stores/authStore.ts`** — Store de Zustand:

```typescript
import { create } from 'zustand'

interface AuthState {
  profile: Profile | null
  setProfile: (profile: Profile | null) => void
  isOwner: () => boolean
  isReceptionist: () => boolean
  isMechanic: () => boolean
}
```

**`src/app/(dashboard)/layout.tsx`** — Layout protegido:
- Server Component que verifica sesión
- Obtener perfil del usuario desde Supabase
- Renderizar `<Sidebar>` y `<Header>` con los datos del usuario
- Si no hay sesión: redirect a login (segunda línea de defensa después del middleware)

### Reglas de acceso por rol

```typescript
// Usar este helper en toda la app
export function canAccess(role: UserRole, route: string): boolean {
  const permissions = {
    owner: ['/', '/orders', '/vehicles', '/commissions', '/mechanics', '/reports'],
    receptionist: ['/', '/orders', '/vehicles'],
    mechanic: ['/orders'],
  }
  return permissions[role].some(r => route.startsWith(r))
}
```

---

## SKILL 03 — Sidebar y navegación

### Objetivo
Navegación lateral que muestra solo las rutas a las que el usuario tiene acceso.

### Comportamiento
- Desktop: sidebar fijo a la izquierda (240px)
- Mobile: bottom navigation bar con 3-4 iconos principales
- El sidebar colapsa en pantallas medianas (tablet) a solo iconos con tooltip
- Nombre del taller arriba, perfil del usuario abajo

### Items de navegación por rol

```typescript
const NAV_ITEMS = {
  owner: [
    { href: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { href: '/orders', icon: ClipboardList, label: 'Órdenes' },
    { href: '/vehicles', icon: Car, label: 'Vehículos' },
    { href: '/commissions', icon: DollarSign, label: 'Comisiones' },
    { href: '/mechanics', icon: Users, label: 'Mecánicos' },
    { href: '/reports', icon: BarChart3, label: 'Reportes' },
  ],
  receptionist: [
    { href: '/orders', icon: ClipboardList, label: 'Órdenes' },
    { href: '/vehicles', icon: Car, label: 'Vehículos' },
  ],
  mechanic: [
    { href: '/orders', icon: ClipboardList, label: 'Mis órdenes' },
  ],
}
```

### Iconos
Usar `lucide-react`. Instalar si no está: `npm install lucide-react`

---

## SKILL 04 — Módulo de órdenes de servicio

### Objetivo
CRUD completo de órdenes. Es el módulo más importante del sistema.

### Vista principal `/orders`

Dos modos de visualización con toggle:

**Modo Kanban:**
- 7 columnas, una por estado
- Cada columna muestra nombre del estado + contador de órdenes
- Cards arrastrables entre columnas (usar `@hello-pangea/dnd`: `npm install @hello-pangea/dnd`)
- Card muestra: placa, propietario, marca/modelo, mecánicos asignados, tiempo en estado actual
- En móvil: scroll horizontal entre columnas

**Modo Lista:**
- Tabla con columnas: #, Placa, Propietario, Vehículo, Estado, Recepcionista, Mecánicos, Fecha entrada
- Ordenable por columna
- Búsqueda por placa o propietario (filtro en tiempo real)

### Crear orden `/orders/new`

Flujo en un solo formulario (NO wizard multipaso — aumenta fricción):

```
Sección 1: Vehículo
- Campo "Placa" con búsqueda en tiempo real
  → Si la placa existe en BD: autocompletar marca, modelo, año, propietario, teléfono
  → Si no existe: habilitar campos para ingresarlos nuevos
- Placa (required, uppercase automático)
- Marca (required)
- Modelo (required)  
- Año (opcional)
- Color (opcional)

Sección 2: Propietario
- Nombre completo (required)
- Teléfono (required, formato colombiano)
- Email (opcional)

Sección 3: Servicio
- Kilometraje actual (opcional)
- Descripción del problema (required, textarea)
- Costo estimado de mano de obra (opcional, se puede completar después)
- Fecha estimada de entrega (opcional)
- Notas internas (opcional)

Sección 4: Asignación
- Recepcionista (required — por defecto el usuario actual si es recepcionista)
- Mecánico(s) (multi-select, opcional en creación)
```

### Detalle de orden `/orders/[id]`

Layout de dos columnas:
- **Izquierda:** Info del vehículo + propietario + descripción del problema + notas
- **Derecha:** Estado actual + historial de estados + mecánicos asignados + costos

**Cambio de estado:**
- Botón prominente "Cambiar estado" abre modal
- Modal muestra estado actual → estados posibles (solo avanzar, nunca retroceder excepto owner)
- Campo opcional de nota al cambiar estado
- Al guardar: actualiza en Supabase + aparece en historial automáticamente

**Asignación de mecánicos:**
- Multi-select de mecánicos activos
- Al asignar: se registra el % de comisión actual del mecánico (snapshot)
- El owner puede cambiar asignaciones en cualquier momento

### Validaciones de formulario (Zod)

```typescript
// src/lib/validations/order.schema.ts
import { z } from 'zod'

export const orderSchema = z.object({
  plate: z.string().min(1).max(10).transform(v => v.toUpperCase()),
  brand: z.string().min(1),
  model: z.string().min(1),
  year: z.number().min(1900).max(new Date().getFullYear() + 1).optional(),
  color: z.string().optional(),
  owner_name: z.string().min(2),
  owner_phone: z.string().regex(/^3[0-9]{9}$/, 'Teléfono colombiano inválido'),
  owner_email: z.string().email().optional().or(z.literal('')),
  mileage: z.number().positive().optional(),
  problem_description: z.string().min(10),
  labor_cost: z.number().min(0).optional(),
  estimated_delivery: z.date().optional(),
  internal_notes: z.string().optional(),
  receptionist_id: z.string().uuid(),
  mechanic_ids: z.array(z.string().uuid()).optional(),
})
```

### Realtime

```typescript
// En el hook useOrders, suscribirse a cambios en tiempo real
supabase
  .channel('orders-realtime')
  .on('postgres_changes', 
    { event: '*', schema: 'public', table: 'service_orders' },
    (payload) => {
      // Actualizar el store local de Zustand sin recargar página
    }
  )
  .subscribe()
```

---

## SKILL 05 — Módulo de comisiones

### Objetivo
El dueño ve en todo momento cuánto le debe a cada mecánico y puede marcar pagos.

### Vista `/commissions`

**Sección superior: Comisiones pendientes**
- Una card por mecánico activo
- Muestra: nombre, foto/avatar, número de órdenes entregadas pendientes de pago, monto total
- Botón "Pagar" por mecánico → abre modal de confirmación

**Modal de pago:**
- Muestra detalle: lista de órdenes incluidas en el pago con sus montos
- Campo opcional: notas del pago
- Botón confirmar → marca `is_commission_paid = true` en todos los `order_mechanics` del mecánico + crea registro en `commission_periods`

**Sección inferior: Historial de pagos**
- Lista de cortes anteriores
- Filtro por mecánico y por período
- Cada fila muestra: mecánico, fecha de corte, monto, si fue pagado

### Lógica de cálculo

Las comisiones se calculan automáticamente vía el trigger de Supabase al marcar una orden como `delivered`. El frontend solo lee, no calcula.

```typescript
// Query para comisiones pendientes
const { data } = await supabase
  .from('pending_commissions')  // Vista creada en DATABASE.md
  .select('*')

// Marcar pago de comisiones de un mecánico
const payCommissions = async (mechanicId: string) => {
  const { error } = await supabase
    .from('order_mechanics')
    .update({ is_commission_paid: true, paid_at: new Date().toISOString() })
    .eq('mechanic_id', mechanicId)
    .eq('is_commission_paid', false)
  // Luego insertar en commission_periods con el resumen
}
```

---

## SKILL 06 — Dashboard del dueño

### Objetivo
Una pantalla que le dice al dueño todo lo importante sin tener que buscar.

### Layout de la pantalla `/`

**Fila 1 — KPIs del día (4 cards):**
- Órdenes activas (todas las que no están en `delivered`)
- Recibidas hoy
- Listas para entregar (`status = 'ready'`)
- Ingresos del día (suma de `labor_cost` de órdenes entregadas hoy)

**Fila 2 — Comisiones pendientes (card resumen):**
- Total a pagar a todos los mecánicos
- Lista resumida por mecánico
- Link a `/commissions` para el detalle

**Fila 3 — Órdenes activas (tabla):**
- Columnas: #, Placa, Propietario, Estado, Mecánico, Días en taller
- Ordenadas por tiempo en taller (más antiguas primero)
- Highlight en rojo si llevan más de 7 días
- Click en fila → va a `/orders/[id]`

### Datos en tiempo real

El dashboard se actualiza automáticamente vía Supabase Realtime cuando cambia cualquier orden. No requiere refresh manual.

---

## SKILL 07 — Gestión de mecánicos

### Objetivo
El dueño puede crear empleados y configurar sus comisiones.

### Vista `/mechanics`

- Lista de todos los mecánicos activos
- Card por mecánico: nombre, teléfono, % de comisión, órdenes activas actuales, total ganado (histórico)
- Botón crear nuevo mecánico → modal con formulario
- Botón editar → modal con datos pre-cargados

### Crear mecánico

El dueño ingresa:
- Nombre completo
- Teléfono
- Email (se usa para el login del mecánico)
- Porcentaje de comisión (ej: 30%)

Proceso:
1. Crear usuario en Supabase Auth con `supabase.auth.admin.createUser()` desde una Server Action
2. El trigger de la DB crea automáticamente el perfil
3. Actualizar el perfil con el % de comisión y rol `mechanic`
4. El mecánico recibe email de confirmación (configurar en Supabase Auth)

### Importante
Usar `SUPABASE_SERVICE_ROLE_KEY` para crear usuarios desde el servidor. NUNCA exponer esta key en el cliente.

---

## SKILL 08 — Historial de vehículos

### Vista `/vehicles`

- Buscador principal: por placa o nombre de propietario
- Resultados en tiempo real mientras escribe
- Click en resultado → ficha completa del vehículo

### Vista `/vehicles/[id]`

- Info del vehículo: placa, marca, modelo, año, color
- Info del propietario: nombre, teléfono, email
- Historial de servicios: lista cronológica de todas las órdenes, con estado, costo, mecánico y fecha
- Botón "Nueva orden" pre-cargado con los datos de este vehículo

---

## SKILL 09 — UI/UX — Principios de diseño

### Objetivo
Una interfaz que use el mecánico con las manos sucias y sin frustración.

### Reglas obligatorias

1. **Botones grandes en móvil:** mínimo 44px de altura táctil en todos los elementos interactivos
2. **Sin modales anidados:** máximo un modal abierto a la vez
3. **Feedback inmediato:** toda acción muestra toast de confirmación o error en menos de 300ms (optimistic updates cuando sea posible)
4. **Loading skeletons:** nunca mostrar pantalla en blanco. Siempre skeleton mientras carga
5. **Errores en lenguaje humano:** "No se pudo guardar la orden" en lugar de "Error 500"
6. **Confirmación para acciones destructivas:** marcar pago, cambiar a entregado → siempre pedir confirmación
7. **Búsqueda instantánea:** el filtro de órdenes por placa funciona mientras se escribe, sin botón de buscar

### Paleta de colores (Tailwind)

```css
/* Usar variables CSS en tailwind.config.ts */
primary: /* azul oscuro para acciones principales */
success: /* verde para estados positivos y órdenes listas */
warning: /* amarillo para alertas y órdenes atrasadas */
destructive: /* rojo para acciones destructivas */
```

### Responsive

- Mobile first: diseñar primero para celular (los mecánicos usan celular)
- El kanban en móvil muestra columnas deslizables horizontalmente
- Los formularios en móvil ocupan pantalla completa (bottom sheet en lugar de modal central)

---

## SKILL 10 — Calidad y producción

### Antes de hacer deploy

1. **Variables de entorno:** verificar que `.env.local` no está en el repositorio. Agregar al `.gitignore`
2. **RLS verificado:** probar que un mecánico autenticado NO puede ver órdenes de otros mecánicos desde el cliente de Supabase
3. **Tipos de TypeScript:** sin errores en `tsc --noEmit`
4. **Errores de consola:** cero errores en consola en producción
5. **Realtime:** verificar que los cambios de estado se reflejan sin recargar en otro browser abierto

### Errores comunes a evitar

```typescript
// ❌ MAL: nunca hacer queries sin manejo de error
const { data } = await supabase.from('service_orders').select()

// ✅ BIEN: siempre destructurar error y manejarlo
const { data, error } = await supabase.from('service_orders').select()
if (error) {
  toast.error('No se pudieron cargar las órdenes')
  console.error(error)
  return
}

// ❌ MAL: nunca exponer SUPABASE_SERVICE_ROLE_KEY en componentes cliente
// ✅ BIEN: solo usarla en Server Actions o Route Handlers

// ❌ MAL: nunca confiar en el rol del token JWT para RLS (puede estar desactualizado)
// ✅ BIEN: las políticas RLS consultan la tabla profiles en tiempo real

// ❌ MAL: mutaciones optimistas sin rollback
// ✅ BIEN: si la mutación falla, revertir el estado local y mostrar error
```

### Configuración de Vercel

Variables de entorno a configurar en Vercel:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

El deploy es automático al hacer push a `main`.
