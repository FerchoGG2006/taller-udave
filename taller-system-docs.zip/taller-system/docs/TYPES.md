# Types — Tipos de la aplicación

Este archivo documenta los tipos principales que el IDE debe implementar en `src/types/app.types.ts`.

```typescript
// src/types/app.types.ts

import type { Database } from './database.types'

// ─── Tipos base de la DB ───────────────────────────────────────────────────

export type Profile = Database['public']['Tables']['profiles']['Row']
export type Vehicle = Database['public']['Tables']['vehicles']['Row']
export type ServiceOrder = Database['public']['Tables']['service_orders']['Row']
export type OrderMechanic = Database['public']['Tables']['order_mechanics']['Row']
export type OrderStatusHistory = Database['public']['Tables']['order_status_history']['Row']
export type CommissionPeriod = Database['public']['Tables']['commission_periods']['Row']

// ─── Enums ─────────────────────────────────────────────────────────────────

export type UserRole = 'owner' | 'receptionist' | 'mechanic'

export type OrderStatus =
  | 'received'
  | 'diagnosing'
  | 'waiting_parts'
  | 'in_progress'
  | 'quality_check'
  | 'ready'
  | 'delivered'

// ─── Tipos compuestos (joins) ──────────────────────────────────────────────

export type MechanicInOrder = {
  id: string
  name: string
  commission_percentage: number
  commission_amount: number
  is_commission_paid: boolean
}

export type OrderFull = ServiceOrder & {
  vehicle: Vehicle
  receptionist: Pick<Profile, 'id' | 'full_name'>
  mechanics: MechanicInOrder[]
}

// ─── Dashboard ─────────────────────────────────────────────────────────────

export type DashboardStats = {
  active_orders: number
  received_today: number
  ready_for_delivery: number
  delivered_today: number
  revenue_today: number
  pending_revenue: number
}

export type PendingCommission = {
  mechanic_id: string
  mechanic_name: string
  pending_orders: number
  total_pending: number
  oldest_order_date: string
}

// ─── Configuración de estados ──────────────────────────────────────────────

export type OrderStatusConfig = {
  label: string
  color: string
  nextStatuses: OrderStatus[]
}

export const ORDER_STATUS_CONFIG: Record<OrderStatus, OrderStatusConfig> = {
  received: {
    label: 'Recibido',
    color: 'bg-slate-100 text-slate-700 border-slate-200',
    nextStatuses: ['diagnosing'],
  },
  diagnosing: {
    label: 'Diagnóstico',
    color: 'bg-blue-100 text-blue-700 border-blue-200',
    nextStatuses: ['waiting_parts', 'in_progress'],
  },
  waiting_parts: {
    label: 'Esperando piezas',
    color: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    nextStatuses: ['in_progress'],
  },
  in_progress: {
    label: 'En proceso',
    color: 'bg-orange-100 text-orange-700 border-orange-200',
    nextStatuses: ['quality_check'],
  },
  quality_check: {
    label: 'Control calidad',
    color: 'bg-purple-100 text-purple-700 border-purple-200',
    nextStatuses: ['ready', 'in_progress'],
  },
  ready: {
    label: 'Listo',
    color: 'bg-green-100 text-green-700 border-green-200',
    nextStatuses: ['delivered'],
  },
  delivered: {
    label: 'Entregado',
    color: 'bg-gray-100 text-gray-500 border-gray-200',
    nextStatuses: [],
  },
}

// ─── Formularios ───────────────────────────────────────────────────────────

export type CreateOrderFormData = {
  // Vehículo
  plate: string
  brand: string
  model: string
  year?: number
  color?: string
  // Propietario
  owner_name: string
  owner_phone: string
  owner_email?: string
  // Servicio
  mileage?: number
  problem_description: string
  labor_cost?: number
  estimated_delivery?: Date
  internal_notes?: string
  // Asignación
  receptionist_id: string
  mechanic_ids?: string[]
}

export type UpdateOrderStatusData = {
  order_id: string
  new_status: OrderStatus
  note?: string
}
```
