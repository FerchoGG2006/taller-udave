# Sistema de Gestión — Talleres Mecánicos

Sistema web de control operativo para talleres mecánicos. Construido con Next.js 15 + Supabase.

## Documentación para el IDE

Lee estos archivos en orden antes de escribir código:

| Archivo | Contenido |
|---------|-----------|
| `docs/PRD.md` | Qué construir, para quién y por qué |
| `docs/DATABASE.md` | Schema SQL completo de Supabase (ejecutar primero) |
| `docs/ARCHITECTURE.md` | Stack, estructura de carpetas, convenciones |
| `docs/SKILLS.md` | Instrucciones paso a paso por módulo |
| `docs/TYPES.md` | Tipos TypeScript de la aplicación |
| `.cursor/rules` | Reglas de Cursor para consistencia de código |

## Setup rápido

```bash
# 1. Instalar dependencias
npm install

# 2. Configurar variables de entorno
cp .env.example .env.local
# Editar .env.local con tus credenciales de Supabase

# 3. Ejecutar migraciones en Supabase
# Copiar y ejecutar el contenido de docs/DATABASE.md en el SQL Editor de Supabase

# 4. Generar tipos de TypeScript desde Supabase
npx supabase gen types typescript --project-id TU_PROJECT_ID > src/types/database.types.ts

# 5. Correr en desarrollo
npm run dev
```

## Módulos

- **Órdenes de servicio** — CRUD completo con kanban y vista lista
- **Comisiones** — Control de pagos a mecánicos por trabajo
- **Dashboard** — Métricas en tiempo real para el dueño
- **Vehículos** — Historial completo por placa
- **Mecánicos** — Gestión de empleados y porcentajes

## Roles

| Rol | Acceso |
|-----|--------|
| `owner` | Todo |
| `receptionist` | Órdenes + Vehículos |
| `mechanic` | Solo sus órdenes asignadas |
